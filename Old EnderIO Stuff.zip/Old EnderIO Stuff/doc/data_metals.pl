our $ores = [

	{
		name => 'ElectricalSteel', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'EnergeticAlloy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'VibrantAlloy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'RedstoneAlloy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'ConductiveIron', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'PulsatingIron', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'DarkSteel', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Soularium', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Bronze', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Enderium', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Signalum', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Lumium', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Invar', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Hepatizon', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'DamascusSteel', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Angmallen', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Brass', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Electrum', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'ShadowSteel', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Inolashite', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Amordrine', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'BlackSteel', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Quicksilver', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Haderoth', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Celenegil', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Tartarite', mod => 'Metallurgy', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Cyanite', mod => 'Tiny Reactors', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Blutonium', mod => 'Tiny Reactors', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Graphite', mod => 'Tiny Reactors', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Ludicrite', mod => 'Tiny Reactors', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'Manyullyn', mod => 'TiC', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},

	{
		name => 'AluminumBrass', mod => 'TiC', requ => 'false',
		dust => 'dust*', ingot => 'ingot*', block => 'block*',
	},












];
