#!/bin/sh
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-base/src/main/resources/assets/enderio/config/recipes/examples/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-conduits/src/main/resources/assets/enderio/config/recipes/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-conduits/src/main/resources/assets/enderio/config/recipes/examples/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-conduits-appliedenergistics/src/main/resources/assets/enderio/config/recipes/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-conduits-opencomputers/src/main/resources/assets/enderio/config/recipes/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-conduits-refinedstorage/src/main/resources/assets/enderio/config/recipes/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-endergy/src/main/resources/assets/enderio/config/recipes/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-integration-forestry/src/main/resources/assets/enderio/config/recipes/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-invpanel/src/main/resources/assets/enderio/config/recipes/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-machines/src/main/resources/assets/enderio/config/recipes/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-machines/src/main/resources/assets/enderio/config/recipes/examples/recipes.xsd
cp ./enderio-base/src/main/resources/assets/enderio/config/recipes/recipes.xsd ./enderio-zoo/src/main/resources/assets/enderio/config/recipes/recipes.xsd

