package crazypants.enderio.base.filter.fluid.items;

import crazypants.enderio.base.filter.IItemFilterUpgrade;
import crazypants.enderio.base.filter.fluid.IFluidFilter;

public interface IItemFilterFluidUpgrade extends IItemFilterUpgrade<IFluidFilter> {

}
