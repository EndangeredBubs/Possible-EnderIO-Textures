@API(apiVersion = EnderIOAPIProps.VERSION, owner = "enderio", provides = "enderioapi|upgrades")
package crazypants.enderio.api.upgrades;

import crazypants.enderio.api.EnderIOAPIProps;
import net.minecraftforge.fml.common.API;
