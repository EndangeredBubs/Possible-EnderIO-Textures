package crazypants.enderio.base.conduit.geom;

public enum ConduitConnectorType {

  INTERNAL,
  EXTERNAL

}
