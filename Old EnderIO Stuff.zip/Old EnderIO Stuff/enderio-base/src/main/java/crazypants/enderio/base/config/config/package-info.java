@ParametersAreNonnullByDefault // Not the right one, but eclipse knows only 3 null annotations anyway, so it's ok
package crazypants.enderio.base.config.config;

import javax.annotation.ParametersAreNonnullByDefault;
