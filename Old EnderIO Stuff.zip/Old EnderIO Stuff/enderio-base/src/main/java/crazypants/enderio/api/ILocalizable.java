package crazypants.enderio.api;

import javax.annotation.Nonnull;

public interface ILocalizable {

  @Nonnull
  String getUnlocalizedName();

}
