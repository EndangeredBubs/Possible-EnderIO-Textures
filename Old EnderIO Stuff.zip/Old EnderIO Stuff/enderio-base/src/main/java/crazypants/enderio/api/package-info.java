@API(apiVersion = EnderIOAPIProps.VERSION, owner = "enderio", provides = "enderioapi")
package crazypants.enderio.api;

import net.minecraftforge.fml.common.API;

