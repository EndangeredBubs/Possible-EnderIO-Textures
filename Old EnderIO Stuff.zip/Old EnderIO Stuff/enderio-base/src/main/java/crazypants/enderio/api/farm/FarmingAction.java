package crazypants.enderio.api.farm;

public enum FarmingAction {
  TILL,
  PLANT,
  HARVEST,
  FERTILIZE;
}
