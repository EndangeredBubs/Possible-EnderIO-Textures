package thaumcraft.api.entities;

public interface ITaintedMob {

}
